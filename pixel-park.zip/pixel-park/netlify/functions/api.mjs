import { getStore } from "@netlify/blobs";
import { pbkdf2Sync, randomBytes, timingSafeEqual } from "node:crypto";

const J = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
const okName = (n) => /^[A-Za-z0-9_]{3,16}$/.test(n || "");
const hashPw = (p, salt) => pbkdf2Sync(p, salt, 100000, 32, "sha256").toString("hex");
const eq = (a, b) => {
  a = Buffer.from(String(a));
  b = Buffer.from(String(b));
  return a.length === b.length && timingSafeEqual(a, b);
};
const clean = (s) => {
  const o = {};
  if (s && typeof s === "object")
    for (const k of Object.keys(s).slice(0, 80)) {
      const v = Number(s[k]);
      if (/^[a-z0-9_]{1,20}$/i.test(k) && Number.isFinite(v) && v >= 0 && v < 1e12) o[k] = Math.floor(v);
    }
  return o;
};

export default async (req) => {
  if (req.method !== "POST") return J({ e: "method" }, 405);
  let b;
  try { b = await req.json(); } catch { return J({ e: "bad" }, 400); }
  const S = getStore("pixelpark");
  const acc = (n) => S.get("acc/" + n.toLowerCase(), { type: "json" });

  if (b.a === "ping") return J({ ok: 1 });

  if (b.a === "reg") {
    if (!okName(b.u) || typeof b.p !== "string" || b.p.length < 6 || b.p.length > 100) return J({ e: "bad" }, 400);
    if (await acc(b.u)) return J({ e: "taken" }, 409);
    const salt = randomBytes(16).toString("hex"), tok = randomBytes(24).toString("hex"), scores = clean(b.scores);
    await S.setJSON("acc/" + b.u.toLowerCase(), { name: b.u, salt, hash: hashPw(b.p, salt), tok, scores });
    return J({ name: b.u, tok, scores });
  }

  if (b.a === "login") {
    const d = okName(b.u) && (await acc(b.u));
    if (!d || typeof b.p !== "string" || !eq(hashPw(b.p, d.salt), d.hash)) return J({ e: "wrong" }, 401);
    d.tok = randomBytes(24).toString("hex");
    await S.setJSON("acc/" + b.u.toLowerCase(), d);
    return J({ name: d.name, tok: d.tok, scores: d.scores || {} });
  }

  if (b.a === "ren") {
    const d = okName(b.u) && okName(b.n) && (await acc(b.u));
    if (!d || !eq(b.tok, d.tok)) return J({ e: "auth" }, 401);
    const same = b.n.toLowerCase() === b.u.toLowerCase();
    if (!same && (await acc(b.n))) return J({ e: "taken" }, 409);
    d.name = b.n;
    await S.setJSON("acc/" + b.n.toLowerCase(), d);
    if (!same) {
      await S.delete("acc/" + b.u.toLowerCase());
      await S.delete("lb/a_" + b.u.toLowerCase());
    }
    return J({ name: b.n });
  }

  if (b.a === "put") {
    let key, name, sc = clean(b.scores);
    if (b.u) {
      const d = okName(b.u) && (await acc(b.u));
      if (!d || !eq(b.tok, d.tok)) return J({ e: "auth" }, 401);
      d.scores = { ...(d.scores || {}) };
      for (const k in sc) d.scores[k] = Math.max(d.scores[k] || 0, sc[k]);
      await S.setJSON("acc/" + b.u.toLowerCase(), d);
      key = "lb/a_" + b.u.toLowerCase();
      name = d.name;
      sc = d.scores;
    } else {
      if (typeof b.id !== "string" || !/^[\w-]{8,60}$/.test(b.id)) return J({ e: "bad" }, 400);
      key = "lb/g_" + b.id;
      name = String(b.name || "Player").replace(/[^\w ]/g, "").slice(0, 16) || "Player";
      if (await acc(name.replace(/ /g, "_"))) name += "*";
      const o = await S.get(key, { type: "json" });
      if (o) for (const k in o.scores || {}) sc[k] = Math.max(sc[k] || 0, o.scores[k]);
    }
    await S.setJSON(key, { name, scores: sc, t: Date.now() });
    return J({ ok: 1 });
  }

  if (b.a === "board") {
    const g = String(b.g || "");
    if (!/^[a-z0-9_]{1,20}$/i.test(g)) return J({ e: "bad" }, 400);
    const { blobs } = await S.list({ prefix: "lb/" });
    const rows = [];
    for (const x of blobs.slice(0, 300)) {
      const d = await S.get(x.key, { type: "json" });
      const s = d && d.scores && d.scores[g];
      if (s > 0) rows.push({ n: d.name, s });
    }
    rows.sort((a, c) => c.s - a.s);
    const seen = new Set(), out = [];
    for (const r of rows) {
      const k = r.n.toLowerCase();
      if (!seen.has(k)) { seen.add(k); out.push(r); }
      if (out.length === 10) break;
    }
    return J({ rows: out });
  }

  return J({ e: "bad" }, 400);
};

export const config = { path: "/api" };
