PIXEL PARK - deploy notes

1. Deploy from GitHub (recommended): put this folder in a GitHub repo, then in Netlify choose
   "Add new site > Import an existing project" and pick the repo. Leave the build settings alone.
   Or use the CLI from inside this folder:  npx netlify-cli deploy --prod
   (Do NOT use drag-and-drop: it uploads the page but not the server function.)

2. Check the server is alive: open https://YOUR-SITE.netlify.app/api in a browser.
   You should see: {"ok":1,"service":"pixel-park"}
   If you see "Page not found", the function was not deployed - redeploy using step 1.

3. Nothing else to set up. Accounts, leaderboards and Discover use Netlify Blobs automatically.
   The Create tab uses Pixi, a game maker that runs in the browser (no API key needed).
